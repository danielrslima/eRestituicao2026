/**
 * Usuários - JavaScript
 * Lógica para a página de gestão de usuários
 */

// Dados mock de usuários
let usuarios = [
    {
        id: 1,
        nome: 'Administrador Sistema',
        email: 'admin@erestituicao.com.br',
        telefone: '(11) 93713-9391',
        tipo: 'admin',
        status: 'ativo',
        ultimoAcesso: '2026-01-25 10:15',
        permissoes: ['clientes', 'crm', 'kitir', 'financeiro', 'pagamentos', 'relatorios', 'usuarios', 'config']
    },
    {
        id: 2,
        nome: 'Maria Operadora',
        email: 'maria@erestituicao.com.br',
        telefone: '(11) 98765-4321',
        tipo: 'operador',
        status: 'ativo',
        ultimoAcesso: '2026-01-25 09:30',
        permissoes: ['clientes', 'crm', 'kitir']
    },
    {
        id: 3,
        nome: 'João Silva',
        email: 'joao@parceiro.com.br',
        telefone: '(11) 91234-5678',
        tipo: 'parceiro',
        status: 'ativo',
        ultimoAcesso: '2026-01-24 16:45',
        codigoParceiro: 'JOAO2026',
        tipoComissao: 'percentual',
        valorComissao: 10,
        chavePix: 'joao@parceiro.com.br',
        comissaoProdutos: { basico: true, kitIR: true, contrato: false },
        permissoes: ['clientes']
    },
    {
        id: 4,
        nome: 'Ana Souza',
        email: 'ana@parceiro.com.br',
        telefone: '(21) 99876-5432',
        tipo: 'parceiro',
        status: 'ativo',
        ultimoAcesso: '2026-01-23 14:20',
        codigoParceiro: 'ANA2026',
        tipoComissao: 'fixo',
        valorComissao: 5.00,
        chavePix: '123.456.789-00',
        comissaoProdutos: { basico: true, kitIR: true, contrato: true },
        permissoes: ['clientes']
    },
    {
        id: 5,
        nome: 'Carlos Operador',
        email: 'carlos@erestituicao.com.br',
        telefone: '(11) 97654-3210',
        tipo: 'operador',
        status: 'inativo',
        ultimoAcesso: '2026-01-10 11:00',
        permissoes: ['clientes', 'crm']
    },
    {
        id: 6,
        nome: 'Pedro Novo',
        email: 'pedro@parceiro.com.br',
        telefone: '(31) 98888-7777',
        tipo: 'parceiro',
        status: 'pendente',
        ultimoAcesso: null,
        codigoParceiro: 'PEDRO2026',
        tipoComissao: 'percentual',
        valorComissao: 8,
        chavePix: '(31) 98888-7777',
        comissaoProdutos: { basico: true, kitIR: false, contrato: false },
        permissoes: ['clientes']
    }
];

let paginaAtual = 1;
const itensPorPagina = 10;
let usuarioParaExcluir = null;

// Inicialização
document.addEventListener('DOMContentLoaded', function() {
    // Verificar autenticação
    if (typeof verificarAutenticacao === 'function') {
        verificarAutenticacao();
    }
    
    // Atualizar data
    atualizarData();
    
    // Carregar nome do usuário
    const user = JSON.parse(localStorage.getItem('user') || '{}');
    if (user.nome) {
        document.getElementById('userName').textContent = user.nome;
    }
    
    // Carregar dados
    atualizarCards();
    renderizarTabela();
});

function atualizarData() {
    const options = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
    const data = new Date().toLocaleDateString('pt-BR', options);
    document.getElementById('dataAtual').textContent = data.charAt(0).toUpperCase() + data.slice(1);
}

// Atualizar cards de resumo
function atualizarCards() {
    const total = usuarios.length;
    const ativos = usuarios.filter(u => u.status === 'ativo').length;
    const parceiros = usuarios.filter(u => u.tipo === 'parceiro').length;
    const admins = usuarios.filter(u => u.tipo === 'admin').length;
    
    document.getElementById('totalUsuarios').textContent = total;
    document.getElementById('usuariosAtivos').textContent = ativos;
    document.getElementById('totalParceiros').textContent = parceiros;
    document.getElementById('totalAdmins').textContent = admins;
}

// Renderizar tabela
function renderizarTabela() {
    const filtroTipo = document.getElementById('filtroTipo').value;
    const filtroStatus = document.getElementById('filtroStatus').value;
    const busca = document.getElementById('buscarUsuario').value.toLowerCase();
    
    let usuariosFiltrados = usuarios.filter(u => {
        if (filtroTipo && u.tipo !== filtroTipo) return false;
        if (filtroStatus && u.status !== filtroStatus) return false;
        if (busca && !u.nome.toLowerCase().includes(busca) && !u.email.toLowerCase().includes(busca)) return false;
        return true;
    });
    
    // Paginação
    const inicio = (paginaAtual - 1) * itensPorPagina;
    const fim = inicio + itensPorPagina;
    const usuariosPagina = usuariosFiltrados.slice(inicio, fim);
    
    // Atualizar info de paginação
    document.getElementById('paginacaoInicio').textContent = usuariosFiltrados.length > 0 ? inicio + 1 : 0;
    document.getElementById('paginacaoFim').textContent = Math.min(fim, usuariosFiltrados.length);
    document.getElementById('paginacaoTotal').textContent = usuariosFiltrados.length;
    
    // Renderizar linhas
    const tbody = document.getElementById('tabelaUsuarios');
    tbody.innerHTML = usuariosPagina.map(u => `
        <tr>
            <td>
                <div class="usuario-info">
                    <div class="usuario-avatar">${getIniciais(u.nome)}</div>
                    <div>
                        <div class="usuario-nome">${u.nome}</div>
                        <div class="usuario-telefone">${u.telefone || '-'}</div>
                    </div>
                </div>
            </td>
            <td>${u.email}</td>
            <td><span class="badge badge-${u.tipo}">${getTipoLabel(u.tipo)}</span></td>
            <td><span class="badge badge-${u.status}">${getStatusLabel(u.status)}</span></td>
            <td>${u.ultimoAcesso ? formatarData(u.ultimoAcesso) : 'Nunca'}</td>
            <td>
                <div class="acoes-btns">
                    <button class="btn-acao btn-editar" onclick="editarUsuario(${u.id})" title="Editar">✏️</button>
                    <button class="btn-acao btn-excluir" onclick="excluirUsuario(${u.id})" title="Excluir">🗑️</button>
                </div>
            </td>
        </tr>
    `).join('');
    
    if (usuariosPagina.length === 0) {
        tbody.innerHTML = '<tr><td colspan="6" style="text-align: center; padding: 40px; color: #999;">Nenhum usuário encontrado</td></tr>';
    }
}

// Funções auxiliares
function getIniciais(nome) {
    return nome.split(' ').map(n => n[0]).slice(0, 2).join('').toUpperCase();
}

function getTipoLabel(tipo) {
    const labels = {
        'admin': 'Administrador',
        'operador': 'Operador',
        'parceiro': 'Parceiro'
    };
    return labels[tipo] || tipo;
}

function getStatusLabel(status) {
    const labels = {
        'ativo': 'Ativo',
        'inativo': 'Inativo',
        'pendente': 'Pendente'
    };
    return labels[status] || status;
}

function formatarData(dataStr) {
    const data = new Date(dataStr);
    return data.toLocaleDateString('pt-BR') + ' ' + data.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' });
}

// Filtrar usuários
function filtrarUsuarios() {
    paginaAtual = 1;
    renderizarTabela();
}

// Paginação
function paginaAnterior() {
    if (paginaAtual > 1) {
        paginaAtual--;
        renderizarTabela();
    }
}

function proximaPagina() {
    const totalPaginas = Math.ceil(usuarios.length / itensPorPagina);
    if (paginaAtual < totalPaginas) {
        paginaAtual++;
        renderizarTabela();
    }
}

// Modal de novo usuário
function abrirModalNovoUsuario() {
    document.getElementById('modalUsuarioTitulo').textContent = '➕ Novo Usuário';
    document.getElementById('formUsuario').reset();
    document.getElementById('usuarioId').value = '';
    
    // Esconder campos de comissão inicialmente
    const camposComissao = document.getElementById('camposComissao');
    if (camposComissao) camposComissao.style.display = 'none';
    
    // Resetar campos de comissão para valores padrão
    const tipoComissao = document.getElementById('tipoComissao');
    if (tipoComissao) tipoComissao.value = 'percentual';
    
    const percentualComissao = document.getElementById('percentualComissao');
    if (percentualComissao) percentualComissao.value = '10';
    
    const valorFixoComissao = document.getElementById('valorFixoComissao');
    if (valorFixoComissao) valorFixoComissao.value = '5,00';
    
    // Resetar checkboxes de produtos
    const comissaoBasico = document.getElementById('comissaoBasico');
    if (comissaoBasico) comissaoBasico.checked = true;
    
    const comissaoKitIR = document.getElementById('comissaoKitIR');
    if (comissaoKitIR) comissaoKitIR.checked = true;
    
    const comissaoContrato = document.getElementById('comissaoContrato');
    if (comissaoContrato) comissaoContrato.checked = false;
    
    abrirModal('modalUsuario');
}

// Editar usuário
function editarUsuario(id) {
    const usuario = usuarios.find(u => u.id === id);
    if (!usuario) return;
    
    document.getElementById('modalUsuarioTitulo').textContent = '✏️ Editar Usuário';
    document.getElementById('usuarioId').value = usuario.id;
    document.getElementById('usuarioNome').value = usuario.nome;
    document.getElementById('usuarioEmail').value = usuario.email;
    document.getElementById('usuarioTelefone').value = usuario.telefone || '';
    document.getElementById('usuarioTipo').value = usuario.tipo;
    document.getElementById('usuarioStatus').value = usuario.status;
    document.getElementById('usuarioSenha').value = '';
    
    // Campos de comissão (parceiro e operador)
    const camposComissao = document.getElementById('camposComissao');
    if (usuario.tipo === 'parceiro' || usuario.tipo === 'operador') {
        if (camposComissao) camposComissao.style.display = 'block';
        document.getElementById('parceiroCodigo').value = usuario.codigoParceiro || '';
        document.getElementById('tipoComissao').value = usuario.tipoComissao || 'sem';
        
        if (usuario.tipoComissao === 'percentual') {
            document.getElementById('percentualComissao').value = usuario.valorComissao || 10;
        } else if (usuario.tipoComissao === 'fixo') {
            document.getElementById('valorFixoComissao').value = (usuario.valorComissao || 0).toFixed(2).replace('.', ',');
        }
        
        document.getElementById('parceiroPix').value = usuario.chavePix || '';
        
        // Produtos com comissão
        if (usuario.comissaoProdutos) {
            document.getElementById('comissaoBasico').checked = usuario.comissaoProdutos.basico !== false;
            document.getElementById('comissaoKitIR').checked = usuario.comissaoProdutos.kitIR !== false;
            document.getElementById('comissaoContrato').checked = usuario.comissaoProdutos.contrato === true;
        } else {
            document.getElementById('comissaoBasico').checked = true;
            document.getElementById('comissaoKitIR').checked = true;
            document.getElementById('comissaoContrato').checked = false;
        }
        
        mostrarCamposTipoComissao();
    } else {
        if (camposComissao) camposComissao.style.display = 'none';
    }
    
    // Permissões
    document.getElementById('permClientes').checked = usuario.permissoes.includes('clientes');
    document.getElementById('permCRM').checked = usuario.permissoes.includes('crm');
    document.getElementById('permKitIR').checked = usuario.permissoes.includes('kitir');
    document.getElementById('permFinanceiro').checked = usuario.permissoes.includes('financeiro');
    document.getElementById('permPagamentos').checked = usuario.permissoes.includes('pagamentos');
    document.getElementById('permRelatorios').checked = usuario.permissoes.includes('relatorios');
    document.getElementById('permUsuarios').checked = usuario.permissoes.includes('usuarios');
    document.getElementById('permConfig').checked = usuario.permissoes.includes('config');
    
    abrirModal('modalUsuario');
}

// Mostrar campos de comissão (parceiro e operador)
function mostrarCamposComissao() {
    const tipo = document.getElementById('usuarioTipo').value;
    // Mostrar campos de comissão para parceiro e operador (não para admin)
    const camposComissao = document.getElementById('camposComissao');
    if (camposComissao) {
        camposComissao.style.display = (tipo === 'parceiro' || tipo === 'operador') ? 'block' : 'none';
    }
}

// Mostrar campos conforme tipo de comissão selecionado
function mostrarCamposTipoComissao() {
    const tipoComissao = document.getElementById('tipoComissao').value;
    const grupoPercentual = document.getElementById('grupoPercentual');
    const grupoValorFixo = document.getElementById('grupoValorFixo');
    const camposValorComissao = document.getElementById('camposValorComissao');
    
    if (tipoComissao === 'sem') {
        if (camposValorComissao) camposValorComissao.style.display = 'none';
    } else if (tipoComissao === 'percentual') {
        if (camposValorComissao) camposValorComissao.style.display = 'flex';
        if (grupoPercentual) grupoPercentual.style.display = 'block';
        if (grupoValorFixo) grupoValorFixo.style.display = 'none';
    } else if (tipoComissao === 'fixo') {
        if (camposValorComissao) camposValorComissao.style.display = 'flex';
        if (grupoPercentual) grupoPercentual.style.display = 'none';
        if (grupoValorFixo) grupoValorFixo.style.display = 'block';
    }
}

// Manter compatibilidade com função antiga
function mostrarCamposParceiro() {
    mostrarCamposComissao();
}

// Salvar usuário
function salvarUsuario() {
    const id = document.getElementById('usuarioId').value;
    const nome = document.getElementById('usuarioNome').value;
    const email = document.getElementById('usuarioEmail').value;
    const telefone = document.getElementById('usuarioTelefone').value;
    const tipo = document.getElementById('usuarioTipo').value;
    const status = document.getElementById('usuarioStatus').value;
    const senha = document.getElementById('usuarioSenha').value;
    
    if (!nome || !email || !tipo) {
        alert('Por favor, preencha todos os campos obrigatórios.');
        return;
    }
    
    // Coletar permissões
    const permissoes = [];
    if (document.getElementById('permClientes').checked) permissoes.push('clientes');
    if (document.getElementById('permCRM').checked) permissoes.push('crm');
    if (document.getElementById('permKitIR').checked) permissoes.push('kitir');
    if (document.getElementById('permFinanceiro').checked) permissoes.push('financeiro');
    if (document.getElementById('permPagamentos').checked) permissoes.push('pagamentos');
    if (document.getElementById('permRelatorios').checked) permissoes.push('relatorios');
    if (document.getElementById('permUsuarios').checked) permissoes.push('usuarios');
    if (document.getElementById('permConfig').checked) permissoes.push('config');
    
    const usuarioData = {
        nome,
        email,
        telefone,
        tipo,
        status,
        permissoes,
        ultimoAcesso: null
    };
    
    // Campos de comissão (parceiro e operador)
    if (tipo === 'parceiro' || tipo === 'operador') {
        usuarioData.codigoParceiro = document.getElementById('parceiroCodigo').value || '';
        usuarioData.tipoComissao = document.getElementById('tipoComissao').value || 'sem';
        
        if (usuarioData.tipoComissao === 'percentual') {
            usuarioData.valorComissao = parseFloat(document.getElementById('percentualComissao').value) || 0;
        } else if (usuarioData.tipoComissao === 'fixo') {
            const valorFixoStr = document.getElementById('valorFixoComissao').value || '0';
            usuarioData.valorComissao = parseFloat(valorFixoStr.replace(',', '.')) || 0;
        } else {
            usuarioData.valorComissao = 0;
        }
        
        usuarioData.chavePix = document.getElementById('parceiroPix').value || '';
        
        // Produtos com comissão
        usuarioData.comissaoProdutos = {
            basico: document.getElementById('comissaoBasico').checked,
            kitIR: document.getElementById('comissaoKitIR').checked,
            contrato: document.getElementById('comissaoContrato').checked
        };
    }
    
    if (id) {
        // Editar
        const index = usuarios.findIndex(u => u.id === parseInt(id));
        if (index !== -1) {
            usuarios[index] = { ...usuarios[index], ...usuarioData };
        }
    } else {
        // Novo
        usuarioData.id = Math.max(...usuarios.map(u => u.id)) + 1;
        usuarios.push(usuarioData);
    }
    
    fecharModal('modalUsuario');
    atualizarCards();
    renderizarTabela();
    
    alert(id ? 'Usuário atualizado com sucesso!' : 'Usuário criado com sucesso!');
}

// Excluir usuário
function excluirUsuario(id) {
    const usuario = usuarios.find(u => u.id === id);
    if (!usuario) return;
    
    usuarioParaExcluir = id;
    document.getElementById('nomeUsuarioExcluir').textContent = usuario.nome;
    abrirModal('modalExcluir');
}

function confirmarExclusao() {
    if (usuarioParaExcluir) {
        usuarios = usuarios.filter(u => u.id !== usuarioParaExcluir);
        usuarioParaExcluir = null;
        fecharModal('modalExcluir');
        atualizarCards();
        renderizarTabela();
        alert('Usuário excluído com sucesso!');
    }
}

// Funções de modal
function abrirModal(id) {
    document.getElementById(id).classList.add('active');
}

function fecharModal(id) {
    document.getElementById(id).classList.remove('active');
}

// Toggle sidebar
function toggleSidebar() {
    document.querySelector('.sidebar').classList.toggle('collapsed');
}

// Logout
function logout() {
    localStorage.removeItem('user');
    localStorage.removeItem('token');
    window.location.href = 'login.html';
}
