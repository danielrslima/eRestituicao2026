# ANÁLISE CONSOLIDADA DO PROJETO EXECUTIVO e-RESTITUIÇÃO

**Identificação:** ANALISE-PROJETO-EXEC-25JAN2026
**Data:** 25/01/2026
**Horário de Brasília:** 00:15
**Status:** ANÁLISE CONCLUÍDA - SEM ALTERAÇÕES

---

## 1. O QUE É O SISTEMA e-RESTITUIÇÃO

O sistema e-Restituição é uma plataforma web que calcula automaticamente quanto um profissional autônomo tem direito a receber de volta do Imposto de Renda (IRPF) em ações trabalhistas. O sistema funciona como um **funil de vendas de duas etapas**:

1. **Cliente preenche** os dados (alvarás, DARFs, honorários)
2. **Sistema calcula** o valor a restituir (mas não mostra ainda)
3. **Cliente paga R$ 29,90** para descobrir o valor
4. **Sistema revela** o valor exato
5. **Cliente paga R$ 2.500,00** para receber o KIT IR completo
6. **Sistema oferece** contratar um especialista via WhatsApp

---

## 2. REGRA CRÍTICA: "MESMO ANO" vs "MÚLTIPLOS ANOS"

Esta é a **regra mais importante** do motor de cálculo, que define se o IPCA-E (índice de deflação) será aplicado ou não:

### MESMO ANO (Sem Deflação)
- **Quando:** Todos os alvarás são do **mesmo ano** (ex: todos de 2024)
- **O que acontece:** O sistema **NÃO aplica** a deflação pelo IPCA-E
- **Motivo:** Se todos os valores são do mesmo ano, não há necessidade de corrigir pela inflação

### MÚLTIPLOS ANOS (Com Deflação)
- **Quando:** Os alvarás são de **anos diferentes** (ex: 2021, 2022, 2024)
- **O que acontece:** O sistema **APLICA** a deflação pelo IPCA-E para trazer todos os valores para o mesmo período
- **Motivo:** Valores de anos diferentes precisam ser corrigidos pela inflação para serem comparáveis

### Código da Chave Seletora (motor_js_v2.js - linhas 266-276):
```javascript
// ========== CHAVE SELETORA AUTOMÁTICA ==========
// Detecta se todos os exercícios são do mesmo ano
const anosUnicos = new Set();
linhas.forEach(linha => {
  const ano = linha.dataAlvara.getUTCFullYear();
  anosUnicos.add(ano);
});

const ehMesmoAno = anosUnicos.size === 1;
const usarDeflacaoAjustado = ehMesmoAno ? false : usarDeflacao;
// =========================================
```

---

## 3. ESTRUTURA DE DADOS DE ENTRADA

O motor de cálculo espera receber os seguintes dados:

| Campo | Tipo | Descrição | Exemplo |
|-------|------|-----------|---------|
| **brutoHomologado** | number | Valor total bruto homologado | R$ 2.096.383,50 |
| **tributavelHomologado** | number | Valor total tributável | R$ 1.495.895,65 |
| **numeroMeses** | number | Período total em meses | 49 |
| **linhas** | array | Lista de alvarás com data | 10 registros |
| **darfs** | array | Lista de DARFs com data | 1 registro |

### Estrutura de cada Alvará (linha):
```javascript
{
  dataAlvara: Date,          // Data do alvará (UTC)
  valorAlvara: number,       // Valor do alvará
  valorHonorario: number,    // Valor de honorários
  anoPagoHonorario: number   // Ano em que honorários foram pagos
}
```

### Estrutura de cada DARF:
```javascript
{
  data: Date,     // Data do DARF (UTC)
  valor: number   // Valor do DARF
}
```

---

## 4. ESTRUTURA DE DADOS DE SAÍDA

O motor retorna:

| Campo | Tipo | Descrição |
|-------|------|-----------|
| **totalIrpf** | number | Total IRPF (apenas original, sem SELIC) |
| **descricaoTotal** | string | "Imposto a Restituir" ou "Imposto a Pagar" |
| **exercicios** | array | Resultado detalhado por exercício fiscal |
| **proporcaoTributavel** | number | Proporção tributável (Tributável/Bruto) |
| **totalAlvarasDeflacionados** | number | Total alvarás após deflação |
| **totalDarfOriginal** | number | Total DARF original |

---

## 5. TABELAS DE IRRF (5 TABELAS)

O motor possui 5 tabelas de IRRF para diferentes períodos:

| Tabela | Período | Faixa Isenta |
|--------|---------|--------------|
| TABELA_IR_2015_2023 | 01/04/2015 a 30/04/2023 | Até R$ 1.903,98 |
| TABELA_IR_2023_2024_MAI | 01/05/2023 a 31/01/2024 | Até R$ 2.112,00 |
| TABELA_IR_2024_FEV | 01/02/2024 a 30/04/2025 | Até R$ 2.259,20 |
| TABELA_IR_2025_MAI | 01/05/2025 a 31/12/2025 | Até R$ 2.428,80 |
| TABELA_IR_2026 | 01/01/2026 em diante | Até R$ 2.428,80 |

---

## 6. FLUXO DE CÁLCULO (PASSO A PASSO)

1. **Detectar se é mesmo ano ou múltiplos anos** (Chave Seletora)
2. **Calcular proporção tributável** = tributavelHomologado / brutoHomologado
3. **Processar cada alvará:**
   - Obter exercício fiscal (ano + 1)
   - Aplicar IPCA-E se múltiplos anos
   - Calcular valor deflacionado
4. **Calcular total de alvarás deflacionados**
5. **Distribuir DARF proporcionalmente** entre os exercícios
6. **Para cada exercício:**
   - Somar rendimentos tributáveis (alvarás - honorários)
   - Calcular IR devido pela tabela progressiva
   - Calcular IRPF = DARF - IR Devido
7. **Somar totais**

---

## 7. ARQUIVOS VALIDADOS E BLINDADOS

Os seguintes arquivos estão **VALIDADOS** e **NÃO DEVEM SER ALTERADOS**:

| Arquivo | Descrição | Status |
|---------|-----------|--------|
| motor_js_v2.js | Motor de cálculo JavaScript puro | ✅ 100% VALIDADO |
| irpfCalculationService.ts | Serviço TypeScript original | ✅ BLINDADO |
| Planilha Excel (DIRF) | Fonte da verdade para cálculos | ✅ REFERÊNCIA |

---

## 8. ESTADO ATUAL DO PROJETO (25/01/2026)

### O que está funcionando:
- ✅ Dashboard com login (admin@erestituicao.com.br / admin123)
- ✅ Histórico de Kit IR (data+hora+usuário)
- ✅ Sino de notificações
- ✅ Busca de clientes (startsWith)
- ✅ Firebase configurado (erestituicao-ffa5c, plano Blaze)
- ✅ Coleção "calculos2026" criada no Firebase
- ✅ Motor de cálculo JavaScript (irpf-calculator.js)
- ✅ Frontend salvando cálculos no Firebase

### O que precisa ser validado/corrigido:
- ⚠️ Valor calculado (R$ 47.907,61) precisa validação
- ❌ Dashboard ainda com dados mockados (não integrado com Firebase)
- ❌ Kit IR PDF não está sendo gerado corretamente
- ✅ Fluxo de pagamento PIX (testado e validado em 24/01/2026)

---

## 9. PRÓXIMOS PASSOS RECOMENDADOS

1. **Validar motor de cálculo:** Comparar irpf-calculator.js com motor_js_v2.js validado
2. **Integrar dashboard com Firebase:** Fazer dashboard ler dados da coleção calculos2026
3. **Corrigir Kit IR PDF:** Resolver problema de geração/download
4. **Corrigir fluxo PIX:** Evitar retorno à página inicial
5. **Fazer checkpoint completo:** Documentar estado atual

---

## 10. REGRAS DE OURO (NUNCA ESQUECER)

1. **Planilha Excel é a fonte da verdade** - Toda lógica de cálculo vem dela
2. **Nunca alterar o que foi validado** - Sem consentimento explícito
3. **Números puros no cálculo** - Formatação (R$, vírgulas) só na tela
4. **Upload na Hostinger sempre em ZIP** - Via Gerenciador de Arquivos
5. **Fuso horário sempre Brasília** - `America/Sao_Paulo`

---

**Documento criado para análise e referência - NENHUMA ALTERAÇÃO FOI FEITA NO CÓDIGO**

**Horário de Brasília:** 25/01/2026 - 00:15
